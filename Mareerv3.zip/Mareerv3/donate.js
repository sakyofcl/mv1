window.onload =function(){

    let donateForm=document.getElementById("donate-form");   
    donateForm.addEventListener("submit",(e) => {
        e.preventDefault();
        alert("Thanks for yor donation.")
    });
}
